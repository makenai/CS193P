//
//  KVCAppDelegate.h
//  KVC
//
//  Created by CS193P on 5/13/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class KVCViewController;

@interface KVCAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    KVCViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet KVCViewController *viewController;

@end

