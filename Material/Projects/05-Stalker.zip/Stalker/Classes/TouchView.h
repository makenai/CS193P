//
//  TouchView.h
//  Stalker
//
//  Created by CS193P on 4/15/09.
//  Copyright 2009 Apple, Inc. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface TouchView : UIView {

	IBOutlet UIView *stalker;
}

@end
