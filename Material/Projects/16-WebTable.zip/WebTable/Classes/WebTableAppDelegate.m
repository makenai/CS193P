//
//  WebTableAppDelegate.m
//  WebTable
//
//  Created by CS193P on 5/27/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "WebTableAppDelegate.h"
#import "RootViewController.h"


@implementation WebTableAppDelegate

@synthesize window;
@synthesize navigationController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {
	
	// Configure and show the window
	[window addSubview:[navigationController view]];
	[window makeKeyAndVisible];
}


- (void)applicationWillTerminate:(UIApplication *)application {
	// Save data if appropriate
}


- (void)dealloc {
	[navigationController release];
	[window release];
	[super dealloc];
}

@end
