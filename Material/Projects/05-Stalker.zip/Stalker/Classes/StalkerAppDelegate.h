//
//  StalkerAppDelegate.h
//  Stalker
//
//  Created by CS193P on 4/15/09.
//  Copyright Apple, Inc 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface StalkerAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

