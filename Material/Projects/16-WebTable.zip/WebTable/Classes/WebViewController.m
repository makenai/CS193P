//
//  WebViewController.m
//  WebTable
//
//  Created by CS193P on 5/27/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "WebViewController.h"


@implementation WebViewController

@synthesize url = _url;

- (void)dealloc
{
	[_webView release];
	[_url release];
	[super dealloc];
}

// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
	_webView = [[UIWebView alloc] initWithFrame:CGRectZero];
	_webView.scalesPageToFit = YES;
	
	NSURLRequest *request = [NSURLRequest requestWithURL:self.url];
	[_webView loadRequest:request];
	
	self.view = _webView;
}

- (void)setURL:(NSURL *)url
{
	NSURLRequest *request = [NSURLRequest requestWithURL:self.url];
	[_webView loadRequest:request];
}

/*
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
}
*/

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}

@end
