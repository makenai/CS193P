//
//  KVCViewController.h
//  KVC
//
//  Created by CS193P on 5/13/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Person.h"

@interface KVCViewController : UIViewController {

	Person	*person;
	
	IBOutlet UILabel *outputLabel;
	IBOutlet UITextField *getKeyField;
	IBOutlet UITextField *setValueField;
}

- (IBAction)fetchValue:(id)sender;
- (IBAction)changeValue:(id)sender;

@end

