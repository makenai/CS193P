#warning If you want to build and run this yourself, register for a free Flickr API key and enter it below.
NSString *const FlickrAPIKey = @"FLICKR_API_KEY_GOES_HERE";
