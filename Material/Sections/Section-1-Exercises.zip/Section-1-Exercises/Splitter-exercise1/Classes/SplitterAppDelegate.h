//
//  SplitterAppDelegate.h
//  Splitter
//
//  Created by Troy on 4/10/09.
//  Copyright Stanford 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SplitterAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

