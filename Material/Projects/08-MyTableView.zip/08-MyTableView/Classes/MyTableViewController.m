//
//  MyTableViewController.m
//  MyTableView
//

#import "MyTableViewController.h"

enum {
    InstructorsGroup = 0,
    TeachingAssistantsGroup,
    GuestLecturersGroup
};

@implementation MyTableViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {        
        instructors = [[NSMutableArray alloc] initWithObjects:@"Alan", @"Evan", @"Paul M.", nil];
        teachingAssistants = [[NSMutableArray alloc] initWithObjects:@"Troy", @"Paul S.", nil];
        guestLecturers = [[NSMutableArray alloc] initWithObjects:@"Jason", @"Josh", @"Alex", @"Justin", @"Eric", @"Dan", @"???", nil];
    }
    return self;
}

- (void)dealloc
{
    [instructors release];
    [teachingAssistants release];
    [guestLecturers release];
    
    [super dealloc];
}

// Helper methods
- (NSMutableArray *)namesForSection:(NSInteger)section
{
    switch (section) {
        case InstructorsGroup:
            return instructors;
        case TeachingAssistantsGroup:
            return teachingAssistants;
        case GuestLecturersGroup:
            return guestLecturers;
        default:
            return nil;
    }
}

- (NSString *)nameForIndexPath:(NSIndexPath *)indexPath
{
    return [[self namesForSection:indexPath.section] objectAtIndex:indexPath.row];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[self namesForSection:section] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"DefaultCell"];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:@"DefaultCell"] autorelease];
    }
    
    cell.text = [self nameForIndexPath:indexPath];
    
    return cell;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    switch (section) {
        case InstructorsGroup:
            return @"Instructors";
        case TeachingAssistantsGroup:
            return @"Teaching Assistants";
        case GuestLecturersGroup:
            return @"Guest Lecturers";
        default:
            return nil;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *name = [self nameForIndexPath:indexPath];
    NSString *title = [NSString stringWithFormat:@"You selected %@.", name];
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:title message:@"Now what?" delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
    [alertView show];
    [alertView release];
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

// Implementing this method allows swipe-to-delete.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Remove the name from our array.
	[[self namesForSection:indexPath.section] removeObjectAtIndex:indexPath.row];
    
    // Animate the row deletion (rather than just calling -reloadData)
	[tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationTop];
}

@end
