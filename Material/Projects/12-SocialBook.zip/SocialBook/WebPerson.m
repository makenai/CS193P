//
//  WebPerson.m
//  SocialBook
//
//  Created by Alexandre Aybes on 5/27/08.
//  Copyright 2008 Apple, Inc.. All rights reserved.
//

#import "WebPerson.h"


@implementation WebPerson

@synthesize firstName;
@synthesize lastName;
@synthesize urlString;

@end
