//
//  TouchView.m
//  Stalker
//
//  Created by CS193P on 4/15/09.
//  Copyright 2009 Apple, Inc. All rights reserved.
//

#import "TouchView.h"


@implementation TouchView

// Tell the "stalker" rectangle to move to each touch-down
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	[UIView beginAnimations:@"stalk" context:nil];
	[UIView setAnimationDuration:1];
	[UIView setAnimationBeginsFromCurrentState:YES];
	
	// touches is an NSSet.  Take any single UITouch from the set
	UITouch *touch = [touches anyObject];
	
	// Move the rectangle to the location of the touch
	stalker.center = [touch locationInView:self];
	[UIView commitAnimations];
}

@end
