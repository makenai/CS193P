//
//  ViewFromNibAppDelegate.h
//  ViewFromNib
//

#import <UIKit/UIKit.h>

@class ViewFromNibViewController;

@interface ViewFromNibAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    ViewFromNibViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet ViewFromNibViewController *viewController;

@end

