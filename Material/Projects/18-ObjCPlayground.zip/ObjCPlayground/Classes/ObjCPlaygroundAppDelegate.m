//
//  ObjCPlaygroundAppDelegate.m
//  ObjCPlayground
//
//  Created by Evan Doll on 12/2/08.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//

#import "ObjCPlaygroundAppDelegate.h"
#import <objc/runtime.h>

@interface UIColor (CS193PAdditions)
+ (UIColor *)stanfordColor;
@end

@implementation UIColor (CS193PAdditions)
+ (UIColor *)stanfordColor
{
    return [UIColor colorWithRed:0.8 green:0.0 blue:0.0 alpha:1.0];
}
@end

@interface NSString (CS193PAdditions)
- (NSString *)obnoxiousString;
@end

@implementation NSString (CS193PAdditions)
- (NSString *)obnoxiousString
{
    NSString *string = [self obnoxiousString]; // Once swizzled, this will actually call -uppercaseString!
    string = [@"LOL " stringByAppendingString:string];
    string = [string stringByAppendingString:@"!!!!1!"];
    return string;
}
@end

@implementation ObjCPlaygroundAppDelegate

@synthesize window;

- (void)printAllColors
{
    // Get all class methods for UIColor. If we wanted instance methods instead, we'd just pass [UIColor class] as the first argument.
    unsigned int count = 0;
    Method *methods = class_copyMethodList(object_getClass([UIColor class]), &count);
    for (int i=0; i < count; i++) {
        // For each method, get the name and see if it ends in "Color"
        Method method = methods[i];
        SEL selector = method_getName(method);
        NSString *methodNameString = [NSString stringWithCString:(const char *)selector encoding:NSASCIIStringEncoding];
        if ([methodNameString hasSuffix:@"Color"]) {
            // If so, see if it returns an object.
            char returnType;
            method_getReturnType(method, &returnType, 1);
            BOOL doesReturnObject = (returnType == _C_ID);
            if (doesReturnObject) {
                // If so, log the name.
                NSLog(@"+[UIColor %s]", selector);            
            }
        }
    }
    if (methods) {
        free(methods);
    }    
}

- (void)swizzleStringMethods
{
    Method uppercaseStringMethod = class_getInstanceMethod([NSString class], @selector(uppercaseString));
    Method obnoxiousStringMethod = class_getInstanceMethod([NSString class], @selector(obnoxiousString));
    method_exchangeImplementations(uppercaseStringMethod, obnoxiousStringMethod);
    
    // Now, anytime someone calls -uppercaseString, they'll get the implementation of -obnoxiousString. Cute, yet diabolical.
    NSString *helloWorldString = @"hello world";
    NSLog(@"%@", [helloWorldString uppercaseString]);
    NSLog(@"%@", [@"this could get really annoying" uppercaseString]);
}

- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    [self printAllColors];
    
    [self swizzleStringMethods];
    
    // Override point for customization after application launch
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [window release];
    [super dealloc];
}


@end
