//
//  PickersAppDelegate.h
//  Pickers
//
//  Created by Evan Doll on 5/6/09.
//  Copyright Apple Inc. 2009. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PickersViewController.h"

@interface PickersAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    PickersViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

