//
//  KVCAppDelegate.m
//  KVC
//
//  Created by CS193P on 5/13/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "KVCAppDelegate.h"
#import "KVCViewController.h"

@implementation KVCAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
	
	[viewController addObserver:self forKeyPath:@"person.ssn" options:0 context:viewController];
}

- (void) observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    if (context == viewController) {
		UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Security Warning" message:@"Someone is hacking the system! Contact the authorities!!" delegate:nil cancelButtonTitle:@"Call 911" otherButtonTitles:nil];
		[alert show];
		[alert release];
	}
	else {
		[super observeValueForKeyPath:keyPath ofObject:object change:change context:context];
	}
}



- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
