//
//  RootViewController.m
//  WebTable
//
//  Created by CS193P on 5/27/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "RootViewController.h"
#import "WebTableAppDelegate.h"
#import "WebViewController.h"


@implementation RootViewController

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
}

- (NSString *)title
{
	return @"Table";
}

#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}


// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:CellIdentifier] autorelease];
		cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    // Set up the cell...
	NSString	*string = @"Go to <a href=\"http://cs193p.stanford.edu/\">CS193p website</a>";
	
    CGRect frame = cell.contentView.bounds;
    frame = CGRectInset(frame, 10, 1);
	 UIWebView	*webView = [[UIWebView alloc] initWithFrame:frame];
	 [webView loadHTMLString:string baseURL:nil];
	webView.delegate = self;
	 [cell.contentView addSubview:webView];	
	 
	
    return cell;
}


- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType {
	if (navigationType == UIWebViewNavigationTypeLinkClicked)
	{
		WebViewController	*webController = [[WebViewController alloc] init];
		webController.url = request.URL;
		[self.navigationController pushViewController:webController animated:YES];
		[webController release];
		
		return NO;
	}

	return YES;
}


- (void)dealloc {
    [super dealloc];
}


@end

