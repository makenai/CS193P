//
//  Person.m
//  KVC
//
//  Created by CS193P on 5/13/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import "Person.h"


@implementation Person

@synthesize firstName;
@synthesize lastName;
@synthesize age;
@synthesize mother;

- (id)initWithSSN:(NSString *)newSSN
{
	if (self = [super init])
	{
		ssn = newSSN;
	}
	
	return self;
}

- (void)dealloc
{
	self.firstName = nil;
	self.lastName = nil;
	self.mother = nil;
	[ssn release];
	
	[super dealloc];
}

- (NSString *)name
{
	return [NSString stringWithFormat:@"%@ %@", self.firstName, self.lastName];
}

- (id)valueForUndefinedKey:(NSString *)key
{
	return [NSString stringWithFormat:@"%@ doesn't have a %@", firstName, key];
}

@end
