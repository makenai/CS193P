//
//  StalkerAppDelegate.m
//  Stalker
//
//  Created by CS193P on 4/15/09.
//  Copyright Apple, Inc 2009. All rights reserved.
//

#import "StalkerAppDelegate.h"

@implementation StalkerAppDelegate

@synthesize window;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    

    // Override point for customization after application launch
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [window release];
    [super dealloc];
}


@end
