//
//  PickersAppDelegate.m
//  Pickers
//
//  Created by Evan Doll on 5/6/09.
//  Copyright Apple Inc. 2009. All rights reserved.
//

#import "PickersAppDelegate.h"

@implementation PickersAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(UIApplication *)application {    

    viewController = [[PickersViewController alloc] initWithNibName:@"PickersView" bundle:nil];
    viewController.view.frame = [[UIScreen mainScreen] applicationFrame];
    [window addSubview:viewController.view];
    
    // Override point for customization after application launch
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
