//
//  ObjCPlaygroundAppDelegate.h
//  ObjCPlayground
//
//  Created by Evan Doll on 12/2/08.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ObjCPlaygroundAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

