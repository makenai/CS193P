//
//  SocialBookViewController.h
//  SocialBook
//
//  Created by Alexandre Aybes on 5/17/08.
//  Copyright Apple, Inc. 2008. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SocialBookViewController : UITableViewController {

}

@end

