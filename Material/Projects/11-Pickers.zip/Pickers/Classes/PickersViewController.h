//
//  PickersViewController.h
//  Pickers
//

#import <UIKit/UIKit.h>
#import <AddressBookUI/AddressBookUI.h>
#import "TypeSomethingViewController.h"

@interface PickersViewController : UIViewController <UIImagePickerControllerDelegate, ABPeoplePickerNavigationControllerDelegate, UINavigationControllerDelegate, TypeSomethingViewControllerDelegate>
{
    UIImageView *imageView;
    UILabel *personLabel;
    UILabel *typeSomethingLabel;
}

@property (retain) IBOutlet UIImageView *imageView;
@property (retain) IBOutlet UILabel *personLabel;
@property (retain) IBOutlet UILabel *typeSomethingLabel;

- (IBAction)showImagePicker:(id)sender;
- (IBAction)showPeoplePicker:(id)sender;
- (IBAction)showTypeSomething:(id)sender;

@end
