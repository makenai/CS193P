//
//  ViewFromNibViewController.h
//  ViewFromNib
//

#import <UIKit/UIKit.h>

@interface ViewFromNibViewController : UIViewController {
    UITextField *textField;
}

@property (retain) IBOutlet UITextField *textField;

- (IBAction)doneButtonPressed:(id)sender;

@end

