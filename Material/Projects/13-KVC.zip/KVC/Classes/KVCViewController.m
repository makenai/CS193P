//
//  KVCViewController.m
//  KVC
//
//  Created by CS193P on 5/13/09.
//  Copyright __MyCompanyName__ 2009. All rights reserved.
//

#import "KVCViewController.h"

@implementation KVCViewController

- (void)viewDidLoad
{
	person = [[Person alloc] initWithSSN:@"456 78 9123"];
	person.firstName = @"Evan";
	person.lastName = @"Doll";
	person.age = 36;
	
	Person *mother = [[Person alloc] initWithSSN:@"123 45 6789"];
	mother.firstName = @"Bette";
	mother.lastName = @"Boop";
	mother.age = 63;
	
	person.mother = mother;
	[mother release];
}

- (void)dealloc {
	[person release];
	[outputLabel release];
	
    [super dealloc];
}

- (IBAction)fetchValue:(id)sender
{
	NSString	*keyPath = getKeyField.text;
	id	value = [person valueForKeyPath:keyPath];
	outputLabel.text = [NSString stringWithFormat:@"%@", value];
}

- (IBAction)changeValue:(id)sender
{
	NSString	*keyPath = getKeyField.text;
	NSString	*newValue = setValueField.text;
	[person setValue:newValue forKeyPath:keyPath];
	
	[self fetchValue:nil];
}

@end
