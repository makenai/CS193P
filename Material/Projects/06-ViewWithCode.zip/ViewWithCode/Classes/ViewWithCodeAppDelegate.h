//
//  ViewWithCodeAppDelegate.h
//  ViewWithCode
//

#import <UIKit/UIKit.h>

@class ViewWithCodeViewController;

@interface ViewWithCodeAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    ViewWithCodeViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet ViewWithCodeViewController *viewController;

@end

