//
//  MyTableViewController.m
//  MyTableView
//
//  Created by Evan Doll on 10/21/08.
//  Copyright 2008 __MyCompanyName__. All rights reserved.
//

#import "MyTableViewController.h"

@implementation MyTableViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        allNames = [[NSArray alloc] initWithObjects:@"Evan", @"Alan", @"Paul", @"Troy", @"Alex", @"Jason", @"Steve", @"Shaq", @"Woz", @"Hammer", @"Pee-Wee", nil];
        filteredNames = [allNames mutableCopy];
	}
    return self;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
    [allNames release];
    [filteredNames release];
    
    if (searchBar.delegate == self) {
        searchBar.delegate = nil;
    }
    [searchBar release];
    
    [super dealloc];
}

- (void)viewDidLoad
{
    searchBar = [[UISearchBar alloc] initWithFrame:self.tableView.bounds];
    [searchBar sizeToFit]; // Get the default height for a search bar.
    searchBar.delegate = self;
    
    self.tableView.tableHeaderView = searchBar;
	
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardDidShowNotification object:nil];

	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardDidHideNotification object:nil];

}

#pragma mark -
#pragma mark Search

- (void)searchBar:(UISearchBar *)aSearchBar textDidChange:(NSString *)searchText
{
    // Stop editing and hide the keyboard
//    [aSearchBar endEditing:YES];
    
    // Re-filter the array of names
    [filteredNames removeAllObjects];
    NSString *query = aSearchBar.text;
	
	if (query.length == 0)
	{
		// Only search if we have a non-zero length query string
		[filteredNames addObjectsFromArray:allNames];
	}
	else
	{
		for (NSString *name in allNames) {
			// Start by assuming that the name matches.
			NSRange range = [name rangeOfString:query options:NSCaseInsensitiveSearch];

			if (range.length > 0)
				[filteredNames addObject:name];
		}
	}
    
    // Add a placeholder if we ended up with no results
    if (filteredNames.count == 0) {
        [filteredNames addObject:@"No results found"];
    }
    
    [self.tableView reloadData];
}

#pragma mark -
#pragma mark Table View

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [filteredNames count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [[[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:nil] autorelease];
    
    cell.text = [filteredNames objectAtIndex:indexPath.row];
    
    return cell;
}

#pragma mark -
#pragma mark Keyboard Notifications

- (void)keyboardWillShow:(NSNotification *)notification
{
    CGRect bounds = [[[notification userInfo] objectForKey:UIKeyboardBoundsUserInfoKey] CGRectValue];
    CGPoint center = [[[notification userInfo] objectForKey:UIKeyboardCenterEndUserInfoKey] CGPointValue];
    
    // We need to compute the keyboard and table view frames in window-relative coordinates
    CGRect keyboardFrame = CGRectMake(round(center.x - bounds.size.width/2.0), round(center.y - bounds.size.height/2.0), bounds.size.width, bounds.size.height);
    CGRect tableViewFrame = [self.tableView.window convertRect:self.tableView.frame fromView:self.tableView.superview];
    
    // And then figure out where they overlap
    CGRect intersectionFrame = CGRectIntersection(tableViewFrame, keyboardFrame);
    
    // This assumes that no one else cares about the table view's insets...
    UIEdgeInsets insets = UIEdgeInsetsMake(0, 0, intersectionFrame.size.height, 0);
    [self.tableView setContentInset:insets];
    [self.tableView setScrollIndicatorInsets:insets];
}

- (void)keyboardWillHide:(NSNotification *)notification
{
    // This assumes that no one else cares about the table view's insets...
    [self.tableView setContentInset:UIEdgeInsetsZero];
    [self.tableView setScrollIndicatorInsets:UIEdgeInsetsZero];
}

@end
