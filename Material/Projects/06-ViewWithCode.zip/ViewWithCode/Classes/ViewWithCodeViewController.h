//
//  ViewWithCodeViewController.h
//  ViewWithCode
//

#import <UIKit/UIKit.h>

@interface ViewWithCodeViewController : UIViewController {
    UITextField *textField;
}

- (void)doneButtonPressed:(id)sender;

@end

