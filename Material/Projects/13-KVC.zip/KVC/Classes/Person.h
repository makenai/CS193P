//
//  Person.h
//  KVC
//
//  Created by CS193P on 5/13/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Person : NSObject {

	NSString *firstName;
	NSString *lastName;
	int	age;
	
	Person *mother;

@private
	NSString *ssn;
}

@property (retain) NSString *firstName;
@property (retain) NSString *lastName;
@property (readonly) NSString *name;

@property int age;

@property (retain) Person *mother;

- (id)initWithSSN:(NSString *)newSSN;

@end
