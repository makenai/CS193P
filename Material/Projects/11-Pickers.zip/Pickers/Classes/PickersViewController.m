//
//  PickersViewController.m
//  Pickers
//

#import "PickersViewController.h"


@implementation PickersViewController

@synthesize imageView;
@synthesize personLabel;
@synthesize typeSomethingLabel;

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    personLabel.text = @"Pick a person...";
    typeSomethingLabel.text = @"Type something already...";
}

- (void)dealloc {
    [imageView release];
    [personLabel release];
    [typeSomethingLabel release];
    
    [super dealloc];
}

#pragma mark -
#pragma mark Image Picker

- (IBAction)showImagePicker:(id)sender
{
    UIImagePickerController *imagePickerController = [[UIImagePickerController alloc] init];
    imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    imagePickerController.delegate = self;
    
    [self presentModalViewController:imagePickerController animated:YES];
    
    [imagePickerController release];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
{
    imageView.image = image;
    
    [self dismissModalViewControllerAnimated:YES];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissModalViewControllerAnimated:YES];    
}

#pragma mark -
#pragma mark People Picker

- (IBAction)showPeoplePicker:(id)sender
{
    ABPeoplePickerNavigationController *peoplePickerController = [[ABPeoplePickerNavigationController alloc] init];
    peoplePickerController.peoplePickerDelegate = self;
    
    [self presentModalViewController:peoplePickerController animated:YES];
    
    [peoplePickerController release];
}

- (void)peoplePickerNavigationControllerDidCancel:(ABPeoplePickerNavigationController *)peoplePicker
{
    [self dismissModalViewControllerAnimated:YES];
}

- (BOOL)peoplePickerNavigationController:(ABPeoplePickerNavigationController *)peoplePicker shouldContinueAfterSelectingPerson:(ABRecordRef)person
{
    NSString *name = (NSString *)ABRecordCopyCompositeName(person);
    personLabel.text = [name autorelease];
    
    [self dismissModalViewControllerAnimated:YES];    
    
    return NO;
}

- (BOOL)peoplePickerNavigationController:(ABPeoplePickerNavigationController *)peoplePicker shouldContinueAfterSelectingPerson:(ABRecordRef)person property:(ABPropertyID)property identifier:(ABMultiValueIdentifier)identifier
{
    return NO;
}

#pragma mark -
#pragma mark Type Something

- (IBAction)showTypeSomething:(id)sender
{
    TypeSomethingViewController *typeSomethingViewController = [[TypeSomethingViewController alloc] init];
    typeSomethingViewController.delegate = self;
    
    [self presentModalViewController:typeSomethingViewController animated:YES];
    
    [typeSomethingViewController release];    
}

- (void)typeSomethingViewController:(TypeSomethingViewController *)controller didTypeSomething:(NSString *)text
{
    typeSomethingLabel.text = text;
    
    [self dismissModalViewControllerAnimated:YES];    
}

@end
