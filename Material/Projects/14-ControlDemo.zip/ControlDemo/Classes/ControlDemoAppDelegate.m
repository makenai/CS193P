//
//  ControlDemoAppDelegate.m
//  ControlDemo
//
//  Created by Jason Beaver on 6/4/08.
//  Copyright Apple Inc. 2008. All rights reserved.
//

#import "ControlDemoAppDelegate.h"
#import "ControlDemoViewController.h"

@implementation ControlDemoAppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {	
    [window addSubview:viewController.view];
	[window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
	[window release];
	[super dealloc];
}


@end
