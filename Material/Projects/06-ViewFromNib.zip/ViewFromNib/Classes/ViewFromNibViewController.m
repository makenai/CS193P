//
//  ViewFromNibViewController.m
//  ViewFromNib
//

#import "ViewFromNibViewController.h"

@implementation ViewFromNibViewController

@synthesize textField;

- (IBAction)doneButtonPressed:(id)sender
{
    [textField endEditing:YES];
}

- (void)viewWillAppear:(BOOL)animated
{
    NSString *text = [[NSUserDefaults standardUserDefaults] stringForKey:@"Text"];
    textField.text = text;
}

- (void)viewWillDisappear:(BOOL)animated
{
    NSString *text = textField.text;
    [[NSUserDefaults standardUserDefaults] setObject:text forKey:@"Text"];
}

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (void)dealloc {
    [textField release];
    
    [super dealloc];
}

@end
