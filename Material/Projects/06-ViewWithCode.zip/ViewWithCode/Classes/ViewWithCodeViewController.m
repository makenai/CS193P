//
//  ViewWithCodeViewController.m
//  ViewWithCode
//

#import "ViewWithCodeViewController.h"

@implementation ViewWithCodeViewController

- (void)loadView
{
    // Create the top-level container view.
    UIView *view = [[UIView alloc] initWithFrame:[[UIScreen mainScreen] applicationFrame]];
    view.backgroundColor = [UIColor lightGrayColor];
    view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    
    // Create the text field.
    CGRect textFieldFrame = CGRectInset(view.bounds, 20, 20);
    textFieldFrame.size.height = 31;
    textField = [[UITextField alloc] initWithFrame:textFieldFrame];
    textField.font = [UIFont systemFontOfSize:15.0];
    textField.borderStyle = UITextBorderStyleRoundedRect;
    textField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    [view addSubview:textField];
    // Don't release it here- we want to hold it as an instance variable as well.
    // It's released in the -dealloc method below.
    
    // Create the button
    CGRect buttonFrame = CGRectMake(0, 0, 72, 37);
    buttonFrame.origin.x = view.bounds.size.width - buttonFrame.size.width - 20.0;
    buttonFrame.origin.y = CGRectGetMaxY(textFieldFrame) + 20.0;
    UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect]; // Autoreleased
    button.frame = buttonFrame;
    [button setTitle:@"Done" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(doneButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:button];
    
    // Finally, set the container view as our view property and release it.
    // Using Interface Builder would have been a lot easier...
    self.view = view;
    [view release];
}

- (void)doneButtonPressed:(id)sender
{
    [textField endEditing:YES];
}

- (void)viewWillAppear:(BOOL)animated
{
    NSString *text = [[NSUserDefaults standardUserDefaults] stringForKey:@"Text"];
    textField.text = text;
}

- (void)viewWillDisappear:(BOOL)animated
{
    NSString *text = textField.text;
    [[NSUserDefaults standardUserDefaults] setObject:text forKey:@"Text"];
}

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (void)dealloc {
    [textField release];
    
    [super dealloc];
}

@end
