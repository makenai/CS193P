//
//  ControlDemoAppDelegate.h
//  ControlDemo
//
//  Created by Jason Beaver on 6/4/08.
//  Copyright Apple Inc. 2008. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ControlDemoViewController;

@interface ControlDemoAppDelegate : NSObject <UIApplicationDelegate> {
	IBOutlet UIWindow *window;
	IBOutlet ControlDemoViewController *viewController;
}

@property (nonatomic, retain) UIWindow *window;
@property (nonatomic, retain) ControlDemoViewController *viewController;

@end

