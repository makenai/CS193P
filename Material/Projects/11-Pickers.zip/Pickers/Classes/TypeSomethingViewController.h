//
//  TypeSomethingViewController.h
//  Pickers
//

#import <UIKit/UIKit.h>

@protocol TypeSomethingViewControllerDelegate;

@interface TypeSomethingViewController : UIViewController {
    UITextField *textField;
    id<TypeSomethingViewControllerDelegate> delegate;
}

@property (retain) IBOutlet UITextField *textField;
@property (assign) id<TypeSomethingViewControllerDelegate> delegate;

- (IBAction)doneButtonPressed:(id)sender;

@end

@protocol TypeSomethingViewControllerDelegate <NSObject>

@optional
- (void)typeSomethingViewController:(TypeSomethingViewController *)controller didTypeSomething:(NSString *)text;

@end