//
//  MyTableViewController.h
//  MyTableView
//

#import <UIKit/UIKit.h>


@interface MyTableViewController : UITableViewController {
    NSMutableArray *photoNames;
    NSMutableArray *photoURLs;
}

@end
