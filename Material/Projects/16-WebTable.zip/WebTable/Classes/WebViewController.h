//
//  WebViewController.h
//  WebTable
//
//  Created by CS193P on 5/27/09.
//  Copyright 2009 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface WebViewController : UIViewController <UIWebViewDelegate> {

	UIWebView	*_webView;
	NSURL	*_url;
}

@property (nonatomic, retain) NSURL *url;

@end
