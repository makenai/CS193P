//
//  ControlDemoViewController.h
//  ControlDemo
//
//  Created by Jason Beaver on 6/4/08.
//  Copyright Apple Inc. 2008. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ControlDemoViewController : UIViewController {
	CGRect labelRect;

	UILabel *touchDownLabel;
	UILabel *touchDownRepeatLabel;
	UILabel *touchDragInsideLabel;
	UILabel *touchDragOutsideLabel;
	UILabel *touchDragEnterLabel;
	UILabel *touchDragExitLabel;
	UILabel *touchUpInsideLabel;
	UILabel *touchUpOutsideLabel;
	UILabel *touchCancelLabel;
	
	UIButton *button;
}

@end

