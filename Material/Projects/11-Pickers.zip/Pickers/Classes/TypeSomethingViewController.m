//
//  TypeSomethingViewController.m
//  Pickers
//

#import "TypeSomethingViewController.h"


@implementation TypeSomethingViewController

@synthesize textField;
@synthesize delegate;

- (IBAction)doneButtonPressed:(id)sender
{
    if ([self.delegate respondsToSelector:@selector(typeSomethingViewController:didTypeSomething:)]) {
        [self.delegate typeSomethingViewController:self didTypeSomething:textField.text];
    }
}

- (void)dealloc {
    [textField release];
    [super dealloc];
}


@end
